# Action Forecast

## Endpoints

### Used Software:

REST API\
GraphQL\
\
FastAPI\
Python\
Strawberry GraphQL\
\
Postman

## Model

### Used Software:
